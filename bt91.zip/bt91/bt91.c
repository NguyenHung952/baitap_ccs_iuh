#include "dsk6416_aic23.h"  // Hỗ trợ CODEC DSK6416
#include <math.h>  // Thư viện toán học để tính sin

#ifndef M_PI
#define M_PI 3.14159265358979323846  // Định nghĩa hằng số PI nếu chưa có
#endif

#define FS 8000  // Tần số lấy mẫu 8kHz
#define TABLE_SIZE 32  // Số mẫu trong bảng sin (có thể thay đổi)
#define BUFFSIZE 128  // Kích thước buffer để hiển thị trên Graph

extern Uint32 fs;  // Khai báo biến fs để tránh lỗi linking
Uint32 fs = DSK6416_AIC23_FREQ_8KHZ;  // Gán giá trị fs

short gain = 1;
float tone1 = 3000.0;  // Tần số mặc định 3kHz
float tone2 = 6000.0;  // Tần số mặc định 6kHz

short Sin_table1[TABLE_SIZE];  // Bảng sin cho tone1
short Sin_table2[TABLE_SIZE];  // Bảng sin cho tone2

short gBuffer1[BUFFSIZE];  // Buffer lưu tín hiệu 3kHz
short gBuffer2[BUFFSIZE];  // Buffer lưu tín hiệu 6kHz
short gBuffer3[BUFFSIZE];  // Buffer lưu tín hiệu tổng hợp

// Hàm khởi tạo bảng sin theo tần số
void generate_sin_table(short *table, float freq) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        table[i] = (short)(1000 * sin(2 * M_PI * freq * i / FS));
    }
}

void main() {
    c6416_dsk_init();
    DSK6416_LED_init();
    DSK6416_DIP_init();

    // Tạo bảng sin cho các tần số
    generate_sin_table(Sin_table1, tone1);
    generate_sin_table(Sin_table2, tone2);

    short i = 0;
    while (1) {
        if (DSK6416_DIP_get(1) == 0) {
            DSK6416_LED_on(1);
            gBuffer3[i % BUFFSIZE] = (Sin_table1[i % TABLE_SIZE] + Sin_table2[i % TABLE_SIZE]) / 2;
            output_sample(gBuffer3[i % BUFFSIZE]);
        } else {
            DSK6416_LED_off(1);
        }
        i = (i + 1) % BUFFSIZE;
    }
}
