#include "dsk6416.h"
#include "dsk6416_led.h"
#include "dsk6416_dip.h"
#include <stdio.h>

// Lưu trạng thái LED
int ledState[4] = {0, 0, 0, 0};

void printLedStatus() {
    printf("LED Status: [%d, %d, %d, %d]\n",
           ledState[0], ledState[1], ledState[2], ledState[3]);
}

void main() {
    DSK6416_init();
    DSK6416_LED_init();
    DSK6416_DIP_init();

    while (1) {
        // Kiểm tra trạng thái DIP switch
        int dip1 = DSK6416_DIP_get(0);
        int dip2 = DSK6416_DIP_get(1);

        // Điều khiển LED 1
        if (dip1 == 0) {
            DSK6416_LED_on(0);
            ledState[0] = 1;  // Cập nhật trạng thái LED 1
        } else {
            DSK6416_LED_off(0);
            ledState[0] = 0;
        }

        // Điều khiển LED 2
        if (dip2 == 0) {
            DSK6416_LED_on(1);
            ledState[1] = 1;  // Cập nhật trạng thái LED 2
        } else {
            DSK6416_LED_off(1);
            ledState[1] = 0;
        }

        // In trạng thái LED khi nhấn bất kỳ DIP switch nào
        if (dip1 == 0 || dip2 == 0) {
            printLedStatus();
        }

        DSK6416_waitusec(50000); // 50ms để phản hồi nhanh hơn
    }
}
