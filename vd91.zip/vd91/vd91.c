#include "dsk6416_aic23.h"                     //support file for codec DSK
Uint32 fs = DSK6416_AIC23_FREQ_8KHZ;           //set sampling rate
short loop, loop1 = 0; short i, j, m = 0; short gain = 1; //gain factor
short Sin_table1[8]={0,707,1000,707,0,-707,-1000,-707}; //Sin values
short Sin_table2[4]={0,1000,0,-1000};
#define BUFFSIZE 128
short gBuffer1[BUFFSIZE]; short gBuffer2[BUFFSIZE]; short gBuffer3[BUFFSIZE];
void main()
{
    c6416_dsk_init();
    DSK6416_LED_init();                    //init LED from BSL
    DSK6416_DIP_init();                     //init DIP from BSL
    while(1)                                 //infinite loop
    {
        for(i=0; i< BUFFSIZE; i++)
        {
            if(DSK6416_DIP_get(0)==0)       //=0 if DIP switch #0 pressed
            {
                DSK6416_LED_on(0);          //turn LED #0 ON
                for (loop=0; loop <= 7; loop++)
                {
                    output_sample(Sin_table1[loop]*gain); //output Sin values
                    gBuffer1[i+loop]= (Sin_table1[loop]*gain);
                }
                if (loop == 8) i=i+loop-1, loop = 0;
            }
            else DSK6416_LED_off(0);
        }
        for (j=0; j< BUFFSIZE; j++)
        {
            if(DSK6416_DIP_get(1)==0)
            {
                DSK6416_LED_on(1);
                for (loop1=0; loop1 <= 3; loop1++)
                {
                    output_sample(Sin_table2[loop1]*gain); //output Sin values
                    gBuffer2[j+loop1]=(Sin_table2[loop1]*gain);
                }
                if (loop1 == 4) j=j+loop1-1, loop1 = 0;
            }
            else DSK6416_LED_off(1);
        }
        for (j=0; j< BUFFSIZE; j++)
        {
            if(DSK6416_DIP_get(2)==0)
            {
                DSK6416_LED_on(2);
                gBuffer3[j]=gBuffer1[j]+gBuffer2[j];
                output_sample(gBuffer3[j]*gain);
            }
            else DSK6416_LED_off(2);
        }
    }
}
