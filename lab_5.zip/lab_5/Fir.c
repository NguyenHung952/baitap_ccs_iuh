//Fir.c  FIR filter with the C6416 DSK. Include coefficient file 
#include "lp_4000.h"		   		//coefficient file
#include "dsk6416_aic23.h"				//codec-dsk support file
Uint32 fs=DSK6416_AIC23_FREQ_48KHZ;	//set sampling rate
int yn = 0;				   				//initialize filter's output
short dly[N];  
short gbuffer[200];                  	//delay samples

interrupt void c_int11()	   		//ISR
{
 short i;
 dly[0]=input_sample();					//input newest sample
 yn = 0;                   	 		//initialize filter's output
 for (i = 0; i< N; i++)
	yn += (h[i] * dly[i]);  			//y(n) += h(i)* x(n-i)
 for (i = N-1; i > 0; i--)  			//starting @ end of buffer
   dly[i] = dly[i-1];      			//update delays with data move
 output_sample((short)(yn>>15));    	//scale output filter sample
 gbuffer[i]=((short)(yn>>15)); 
 return;
}

void main()
{
	comm_intr();               		//init DSK, codec, McBSP
  	while(1); //infinite loop
  	//code tang mẫu//
}

