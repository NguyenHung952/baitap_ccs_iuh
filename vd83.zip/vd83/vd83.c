//Sine8_LED.c  Sine generation with DIP switch control
#include "dsk6416_aic23.h"  //support file for codec,DSK
#include<math.h>
#define BUFFSIZE 128
Uint32 fs = DSK6416_AIC23_FREQ_8KHZ;//set sampling rate
int i,k=0;
short gain = 2;                 //gain factor
short sintable_sum[BUFFSIZE];



// Global Variables
short gBuffer[BUFFSIZE][5];
void main()
{
 comm_poll();                       //init DSK,codec,McBSP
 //c6416_dsk_init();

 DSK6416_LED_init();                //init LED from BSL
 DSK6416_DIP_init();                //init DIP from BSL
 for (k=1;k<10;k+=2)
 {
     for (i=0;i<BUFFSIZE;i++){
         gBuffer[i][k/2]=1000*(1.0/k)*sin(2*3.14*k*i/BUFFSIZE);
     }
 }
 for (i=0;i<BUFFSIZE;i++){
     sintable_sum[i]=0;
     for(k=1;k<10;k+=2){
         sintable_sum[i]+=gBuffer[i][k/2];
     }
 }
 while(1)                           //infinite loop
 for (i=0; i< BUFFSIZE; i++)
 {
  if(DSK6416_DIP_get(0)==0)         //=0 if DIP switch #0 pressed
  {
   DSK6416_LED_on(0);//turn LED #0 ON
   output_sample(sintable_sum[i]*gain);//output sine values
  }
  else DSK6416_LED_off(0);
 }                                  //end of while(1) infinite loop
}                                   //end of main


