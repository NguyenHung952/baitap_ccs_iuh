#include "dsk6416_aic23.h"
Uint32 fs = DSK6416_AIC23_FREQ_8KHZ;
short i = 0, loop = 0;
short gain = 1;
#define BUFFSIZE 128

// Sử dụng 32 mẫu để dạng sóng mượt hơn
short sine_table[32] = {
    0, 195, 382, 555, 707, 831, 923, 980, 1000, 980, 923, 831, 707, 555, 382, 195,
    0, -195, -382, -555, -707, -831, -923, -980, -1000, -980, -923, -831, -707, -555, -382, -195
};

short gBuffer[BUFFSIZE];

void main() {
    c6416_dsk_init();
    DSK6416_LED_init();
    DSK6416_DIP_init();

    while(1) {
        for (i = 0; i < BUFFSIZE; i += 32) {
            if (DSK6416_DIP_get(0) == 0) {
                DSK6416_LED_on(0);
                for (loop = 0; loop < 32; loop++) {
                    if (i + loop < BUFFSIZE) {
                        gBuffer[i + loop] = sine_table[loop] * gain;
                    }
                    output_sample(sine_table[loop] * gain);
                    DSK6416_waitusec(125);  // Đúng tốc độ 8 kHz
                }
            } else {
                DSK6416_LED_off(0);
            }
        }
    }
}
