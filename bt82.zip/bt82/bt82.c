// Sine8_LED.c - Sine generation with DIP switch control
#include "dsk6416_aic23.h"  // Support file for codec, DSK
#include <math.h>

#define BUFFSIZE 128
Uint32 fs = DSK6416_AIC23_FREQ_8KHZ;  // Set sampling rate

// Waveform tables
short square_wave_table[8] = {1000, 1000, 1000, 1000, -1000, -1000, -1000, -1000};
short three_angle_wave_table[8] = {0, 250, 500, 750, 1000, 750, 500, 250};
short sawtooth_wave_table[8] = {-1000, -750, -500, -250, 0, 250, 500, 1000};  // Răng cưa
short bipolar_wave_table[8] = {1000, 500, 0, -500, -1000, -500, 0, 500};  // Lưỡng cực

// Global buffer
short gBuffer[BUFFSIZE];

// Function prototypes
void generate_wave(short *wave_table);
void output_wave();

void main()
{
    // Init DSK, codec, McBSP
    c6416_dsk_init();
    DSK6416_LED_init();  // Init LED from BSL
    DSK6416_DIP_init();  // Init DIP from BSL

    while (1) {
        output_wave();
    }
}

// Function to generate waveform buffer
void generate_wave(short *wave_table)
{
    int i, loop;
    for (i = 0; i < BUFFSIZE; i++) {
        gBuffer[i] = wave_table[i % 8];  // Lặp lại mẫu sóng
    }
}

// Function to output waveform
void output_wave()
{
    int i;
    for (i = 0; i < BUFFSIZE; i++) {
        if (DSK6416_DIP_get(0) == 0) {  // Sóng vuông
            DSK6416_LED_on(0);
            generate_wave(square_wave_table);
            output_sample(gBuffer[i] * 2);
        } else {
            DSK6416_LED_off(0);
        }

        if (DSK6416_DIP_get(1) == 0) {  // Sóng tam giác
            DSK6416_LED_on(1);
            generate_wave(three_angle_wave_table);
            output_sample(gBuffer[i] * 2);
        } else {
            DSK6416_LED_off(1);
        }

        if (DSK6416_DIP_get(2) == 0) {  // Sóng răng cưa
            DSK6416_LED_on(2);
            generate_wave(sawtooth_wave_table);
            output_sample(gBuffer[i] * 2);
        } else {
            DSK6416_LED_off(2);
        }

        if (DSK6416_DIP_get(3) == 0) {  // Sóng lưỡng cực
            DSK6416_LED_on(3);
            generate_wave(bipolar_wave_table);
            output_sample(gBuffer[i] * 2);
        } else {
            DSK6416_LED_off(3);
        }
    }
}
