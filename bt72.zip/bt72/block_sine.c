#include <math.h>
#include <stdio.h>

// Định nghĩa M_PI nếu chưa có
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Tần số mong muốn và tần số lấy mẫu
#define F_TONE  28000.0  // 28 kHz
#define F_SAMP  48000.0  // 48 kHz

// Biến toàn cục để lưu giá trị sin/cos
static float y[3] = {0, 0, 0};
static float A;
static float Y1;

// Hàm khởi tạo giá trị sin/cos
void initSineWave() {
    double theta = (F_TONE / F_SAMP) * 2 * M_PI;  // Tính theta
    Y1 = sin(theta);
    A = 2 * cos(theta);
    y[1] = Y1;
}

// Hàm sinh sóng sin
short sineGen(void) 
{ 
    y[0] = y[1] * A - y[2];
    y[2] = y[1];
    y[1] = y[0];

    y[0] *= 32000;  // Scale to 16-bit range

    return (short)y[0];
}

// Hàm tạo block sóng sin
void blockSine(short *buf, int len) 
{ 
    int i; // Khai báo biến i trước vòng for
    for (i = 0; i < len; i++) {
        buf[i]  = sineGen();
    }
}
