#include <stdio.h>
#include <math.h>
#include "dsk6416_aic23.h"  // Codec support file

Uint32 fs = DSK6416_AIC23_FREQ_48KHZ;  // Set sampling rate to 48kHz

// Prototypes
void blockSine(short *buf, int len);
void initSineWave();

// Declarations 
#define BUFFSIZE 128

// Global Variables
short gBuffer[BUFFSIZE];

// ======== main ========
void main()
{
    c6416_dsk_init();
    DSK6416_LED_init();  // Init LED from BSL
    DSK6416_DIP_init();  // Init DIP from BSL

    printf("DSP Bài 7_2\n");

    initSineWave();

    blockSine(gBuffer, BUFFSIZE);  // Fill buffer with sine data
    printf("Bộ nhớ gBuffer (ở địa chỉ %p) được điền với dữ liệu Sin\n", (void*)gBuffer);

    while (1)
    {
        if (DSK6416_DIP_get(0) == 0)  // =0 if DIP switch #0 pressed
        {
            DSK6416_LED_on(0);  // Turn LED #0 ON
        }
        else
        {
            DSK6416_LED_off(0);  // Turn LED #0 OFF
        }
    }
}
