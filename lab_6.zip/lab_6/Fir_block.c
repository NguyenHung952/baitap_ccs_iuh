//Fir.c  FIR filter with the C6416 DSK. Include coefficient file 
#include "bandpass2500_5500.h"		   		//coefficient file
#include "dsk6416_aic23.h"				//codec-dsk support file
//#include "Speech.h"
#include "Speech.h"
Uint32 fs=DSK6416_AIC23_FREQ_44KHZ;	//set sampling rate
int yn = 0;
int GAIN=1;//initialize filter's output
short dly[N];  
             	//delay samples
int temp=0;
#define INPUT_LEN SPEECHBUF
#define OUTPUT_LEN INPUT_LEN
short y[OUTPUT_LEN];
void main()
{
  	//while(1);

  	  int i,n;
  	  comm_poll(); //init dsk6416 board and DAC,ADC
  	  DSK6416_LED_init(); //LEDs init
  	  /*fir filter with block processing   	  */
  	  for(n=0;n<OUTPUT_LEN;n++)
  	  {
  	    short i;
  	     dly[0]=Speech[n];                 //input newest sample
  	     yn = 0;                            //initialize filter's output
  	     for (i = 0; i< N; i++)
  	        yn += (h[i] * dly[i]);              //y(n) += h(i)* x(n-i)
  	     for (i = N-1; i > 0; i--)              //starting @ end of buffer
  	       dly[i] = dly[i-1];               //update delays with data move
  	     output_sample((short)(yn>>15));        //scale output filter sample
  	     y[n]=((short)(yn>>15));

  	  }
  	  //Output to headphone
  	  for(n=0;n<SPEECHBUF;n++)
  	  output_sample(Speech[n]); //Original Voice
  	  for(n=0;n<SPEECHBUF;n++)
  	  output_sample(y[n]); //Filtered Voice

}

