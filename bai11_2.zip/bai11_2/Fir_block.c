#include "dsk6416_aic23.h" // Hỗ trợ codec DSK6416
#include <math.h> // Thư viện toán học để tính sin

#ifndef M_PI
#define M_PI 3.14159265358979323846 // Định nghĩa hằng số PI
#endif

#define FS 48000 // Tần số lấy mẫu 48kHz
#define BUFFSIZE 1000 // Kích thước vùng nhớ (buffer)
#define TABLE_SIZE 1000 // Số mẫu trong bảng tra sóng sin

short sin_table[TABLE_SIZE]; // Bảng tra giá trị sóng sin
short gBuffer[BUFFSIZE]; // Bộ nhớ vùng để hiển thị tín hiệu
float A; // Tần số sóng sin

// Hàm khởi tạo bảng tra sóng sin
void generate_sin_table(short *table, float freq) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        table[i] = (short)(1000 * sin(2 * M_PI * freq * i / FS)); // Tính giá trị sin
    }
}

void main() {
    // Tính tần số AHz từ số thứ tự sinh viên
    int studentID = 8; // Số thứ tự sinh viên
    A = (float)((studentID % 5) + 1) * 100; // Tính tần số AHz

    // Tạo bảng tra sóng sin
    generate_sin_table(sin_table, A);

    // Khởi tạo hệ thống DSK
    c6416_dsk_init();
    DSK6416_LED_init(); // Khởi tạo LED
    DSK6416_DIP_init(); // Khởi tạo DIP switch

    int i = 0;
    while (1) { // Vòng lặp vô tận
        for (i = 0; i < BUFFSIZE; i++) {
            gBuffer[i] = sin_table[i % TABLE_SIZE]; // Lặp giá trị từ bảng tra

            if (DSK6416_DIP_get(0) == 0) { // Kiểm tra trạng thái DIP switch #0
                DSK6416_LED_on(0); // Bật LED #0
                output_sample(gBuffer[i]); // Xuất giá trị sóng sin
            } else {
                DSK6416_LED_off(0); // Tắt LED #0
            }
        }
    }
}
