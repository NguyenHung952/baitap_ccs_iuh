#include "dsk6416.h"
#include "dsk6416_led.h"
#include "dsk6416_flash.h"
#include "dsk6416_dip.h"

void main()
{
    DSK6416_init();
    DSK6416_LED_init();
    while(1)
    {
        DSK6416_LED_toggle(3);
        DSK6416_waitusec(2000000);
        if(DSK6416_DIP_get(0) == 0)
        {
            DSK6416_LED_on(2);
        }
        else
        {
            DSK6416_LED_off(2);
        }
    }
}
