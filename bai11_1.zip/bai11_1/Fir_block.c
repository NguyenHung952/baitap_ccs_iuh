#include "filter_coefficients.h"
#include "audiorecord.h"
#include "dsk6416_aic23.h"

Uint32 fs = DSK6416_AIC23_FREQ_32KHZ; // Tần số mẫu 32kHz
short dly[N];                         // Bộ nhớ đệm cho FIR
short y[SPEECHBUF];                   // Kết quả lọc

void main()
{
    int i, n;
    DSK6416_DIP_init(); // Khởi tạo DIP switch
    c6416_dsk_init();   // Khởi tạo KIT DSP
    DSK6416_LED_init(); // Khởi tạo LED

    // Xử lý lọc FIR
    for (n = 0; n < SPEECHBUF; n++)
    {
        dly[0] = Speech[n]; // Lấy tín hiệu đầu vào
        int yn = 0;         // Giá trị lọc

        // Áp dụng bộ lọc FIR
        for (i = 0; i < N; i++)
            yn += h[i] * dly[i];

        // Dịch bộ nhớ đệm
        for (i = N - 1; i > 0; i--)
            dly[i] = dly[i - 1];

        // Lưu kết quả lọc
        y[n] = (short)(yn >> 15); // Chia tỷ lệ
        output_sample(y[n]);      // Xuất tín hiệu lọc ra DAC
    }

    // Hiển thị kết quả khi DIP switch bật
    while (1)
    {
        if (DSK6416_DIP_get(0) == 0) // Kiểm tra trạng thái DIP switch
        {
            for (n = 0; n < SPEECHBUF; n++)
                output_sample(Speech[n]); // Xuất tín hiệu gốc

            for (n = 0; n < SPEECHBUF; n++)
                output_sample(y[n]); // Xuất tín hiệu đã lọc
        }
    }
}
