#include "dsk6416.h"
#include "dsk6416_led.h"
#include "dsk6416_dip.h"

void main() {
    DSK6416_init();
    DSK6416_LED_init();
    DSK6416_DIP_init();

    while (1) {
        // Kiểm tra trạng thái DIP switch
        int dip1 = DSK6416_DIP_get(0);
        int dip2 = DSK6416_DIP_get(1);

        // Debug trạng thái DIP
        printf("DIP_SW1: %d, DIP_SW2: %d\n", dip1, dip2);

        // Điều khiển LED 1
        if (dip1 == 0) {
            DSK6416_LED_on(0);
        } else {
            DSK6416_LED_off(0);
        }

        // Điều khiển LED 2
        if (dip2 == 0) {
            DSK6416_LED_on(1);
        } else {
            DSK6416_LED_off(1);
        }

        // Không delay quá lâu
        DSK6416_waitusec(100000); // 100ms
    }
}
