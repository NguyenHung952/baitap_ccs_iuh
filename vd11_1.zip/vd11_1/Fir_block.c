#include "lp1500_256.cof"
#include "dsk6416_aic23.h"
#include "audiorecord.h"

Uint32 fs=DSK6416_AIC23_FREQ_44KHZ;

int yn = 0;
int gain = 1;
short dly[N];
int temp = 0;

#define INPUT_LEN SPEECHBUF
#define OUTPUT_LEN INPUT_LEN
short y[OUTPUT_LEN];

void main()
{
    int i, n;
    DSK6416_DIP_init();
    c6416_dsk_init();
    DSK6416_LED_init();

    for(n = 0; n < OUTPUT_LEN; n++)
    {
        short i;
        dly[0] = Speech[n];
        yn = 0;

        for(i = 0; i < N; i++)
            yn += (h[i] * dly[i]);

        for(i = N-1; i > 0; i--)
            dly[i] = dly[i-1];

        output_sample((short)(yn >> 15) * gain);
        y[n] = ((short)(yn >> 15));
    }

    while(1)
    {
        if(DSK6416_DIP_get(0) == 0)
        {
            for(n = 0; n < SPEECHBUF; n++)
                output_sample(Speech[n]);

            for(n = 0; n < SPEECHBUF; n++)
                output_sample(y[n]);
        }
    }
}
