#include "DSK6416_AIC23.h"              //codec-DSK support file
Uint32 fs=DSK6416_AIC23_FREQ_8KHZ;     //set sampling rate
//#include "eliiptic_1000_6order.h"               //coefficient file
//#include "cheb_32000_2order.h"               //coefficient file
//#include"IIR_32000_3000.h"
//#include"cheb_2000_2order.h"
#include"cheb_2000_2order.h"
float w[NUM_SECTIONS][2] = {0};
int gain=1;
interrupt void c_int11()                //ISR
{  
   int section; //index for section number
   float input; //input to each section
   float wn,yn; //intermediate and output               //input to 1st stage
   input = ((float)input_left_sample());
   for (section=0 ; section< NUM_SECTIONS ; section++)
   {
   wn = input - a[section][0]*w[section][0]
   - a[section][1]*w[section][1];
   yn = b[section][0]*wn + b[section][1]*w[section][0]
   + b[section][2]*w[section][1];
   w[section][1] = w[section][0];
   w[section][0] = wn;
   input = yn; //output of current section
   //will be input to next
   }
   output_left_sample((short)(yn)*gain);
    return;                         //return from ISR
}

void main()
{
  comm_intr();
  while(1);

}
