#define NUM_SECTIONS 1
#define L 3
float b[NUM_SECTIONS][L] = {0, 2.745198e-01, 0};
#define M 3
float a[NUM_SECTIONS][M-1] = {-1.170996e+00, 5.318914e-01};
