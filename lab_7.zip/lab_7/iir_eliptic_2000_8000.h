// iir_eliptic_2000_8000.h
// this file was generated automatically using function dsk_sos_iir67.m

#define NUM_SECTIONS 3

float b[NUM_SECTIONS][3] = { 
{2.62545694E-01, -4.88269878E-01, 2.62545694E-01},
{1.24828379E-01, -1.49730234E-01, 1.24828379E-01},
{3.71753659E-03, -7.12866404E-03, 3.71753659E-03} };

float a[NUM_SECTIONS][2] = { 
{-1.93625646E+00, 9.50928058E-01},
{-1.92069065E+00, 9.24243215E-01},
{-1.95972943E+00, 9.83999168E-01} };
