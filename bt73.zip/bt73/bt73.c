#include <stdio.h>
#include <math.h>
#include "dsk6416_aic23.h"
#include "dsk6416.h"
#include "dsk6416_led.h"
#include "dsk6416_dip.h"

#define F_TONE 28000.0   // 28 kHz
#define F_SAMP 48000.0   // 48 kHz

const int N_SAMPLES = (int)(F_SAMP / F_TONE);  // Số mẫu trong một chu kỳ
#define PI 3.14159265358979323846

Uint32 fs = DSK6416_AIC23_FREQ_48KHZ;
short gBuffer[256];  // Định kích thước đủ lớn để tránh lỗi

// ======== Tạo sóng sin ========
void generateSineWave() {
    int i;
    for (i = 0; i < N_SAMPLES; i++) {
        gBuffer[i] = (short)(32000 * sin(2 * PI * i / N_SAMPLES));
    }
}

// ======== Xuất dữ liệu dạng sóng ========
void printWaveform() {
    int i;
    printf("Waveform Data:\n");
    for (i = 0; i < N_SAMPLES; i++) {
        printf("%d\n", gBuffer[i]);
    }
}

// ======== main ========
void main() {
    DSK6416_init();
    DSK6416_LED_init();
    DSK6416_DIP_init();

    printf("DSP Bai 7_3 - Phan tich tin hieu\n");

    generateSineWave();
    printWaveform();

    while (1) {
        if (DSK6416_DIP_get(0) == 0) {
            DSK6416_LED_on(0);
        } else {
            DSK6416_LED_off(0);
        }
    }
}
